
import './App.css'
import CRUD from './Components/CRUD/CRUD';

function App() {
  return (
    <>
    <CRUD />
    </>
  );
}


export default App;
